Moonlight Anti AK47


This isnt our function, we just improved it by alot and added a drop function.

It detects if someone uses the eulen ak47 cheat.

Remember someone else created this function but we made it better