fx_version 'adamant'

version '1.0.0'
lua54 'yes'

author 'Moonlight Anticheat | Moonlight Development Team'

game 'gta5'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}